@include('frontend.layout.header')

@yield('manage_front')

@include('frontend.layout.footer')