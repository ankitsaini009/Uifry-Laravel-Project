@include('admin.layout.header')

@include('admin.layout.sidebar')

@yield('manage_content')

@include('admin.layout.footer')