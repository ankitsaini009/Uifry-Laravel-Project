<?php $__env->startSection('manage_content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h2>Create Testimonial</h2><br>
                <form action="<?php echo e(route('testimonials.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Testimonial_id" value="<?php echo e((isset($Testimonial)?$Testimonial->id:'')); ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" placeholder="Enter Name" value="<?php echo e((isset($Testimonial)?$Testimonial->name:old('name'))); ?>" autocomplete="off">
                            <?php if($errors->has('name')): ?>
                            <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="feedback" class="form-label">Feedback</label>
                            <textarea name="feedback" placeholder="Enter Feedback" id="feedback" class="form-control"><?php echo e((isset($Testimonial) ? $Testimonial->feedback : old('feedback'))); ?></textarea>
                            <?php if($errors->has('feedback')): ?>
                            <div class="text-danger"><?php echo e($errors->first('feedback')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="active" <?php echo e((isset($Testimonial) && $Testimonial->status == 'active') ? 'selected' : (old('status') == 'active' ? 'selected' : '')); ?>>Active</option>
                                <option value="inactive" <?php echo e((isset($Testimonial) && $Testimonial->status == 'inactive') ? 'selected' : (old('status') == 'inactive' ? 'selected' : '')); ?>>Inactive</option>
                            </select>
                            <?php if($errors->has('status')): ?>
                            <div class="text-danger"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="image" class="form-label">Image</label>
                            <?php if(isset($Testimonial) && $Testimonial->image): ?>
                            <div class="mb-2">
                                <img src="<?php echo e(asset('images/' . $Testimonial->image)); ?>" alt="User Image" class="img-thumbnail" width="100">
                            </div>
                            <input type="hidden" value="<?php echo e((isset($Testimonial)?$Testimonial->image:old('image'))); ?>" class="form-control" name="image" autocomplete="off">
                            <?php endif; ?>
                            <input type="file" class="form-control" name="image" autocomplete="off">
                            <?php if($errors->has('image')): ?>
                            <div class="text-danger"><?php echo e($errors->first('image')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br><br>
                    <div class="text-center">
                        <button type="submit" class="btn btn-danger"><?php echo e((isset($Testimonial)? "Update" : "Create")); ?></button>
                        <a href="<?php echo e(route('testimonials.index')); ?>" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    // CKEDITOR.replace('description');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dmprojects/public_html/ankitsaini/laravel-uifry/resources/views/admin/testimonials/add.blade.php ENDPATH**/ ?>