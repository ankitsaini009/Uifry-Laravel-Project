<?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="my-account pb-10 mt-5">
    <div class="container">
        <div class="grid grid-cols-12 lg:gap-5 gap-y-10">
            <?php echo $__env->make('frontend.layout.profile_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-span-12 md:col-span-8">
                <div>
                    <h2 class="lg:text-3xl text-2xl font-semibold text-[#011632]">Current And Upcoming Appointment</h2>
                    <div class="lg:overflow-x-visible overflow-x-auto border lg:border-transparent border-[#DDDDDD] lg:mt-7 mt-5 ">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-[#FFFFFF] text-left text-xs font-semibold text-[#011632] text-nowrap">
                                    <th class="py-5 px-5">DATE AND TIME</th>
                                    <th class="py-5 px-5">NAME</th>
                                    <th class="py-5 px-5">SERVICES</th>
                                    <th class="py-5 px-5">STATUS</th>
                                    <th class="py-5 px-5">PHONE NO.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Apointmentments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border border-[#DDDDDD] text-[#011632] text-sm lg:text-nowrap">
                                    <td class="py-5 px-5 w-full">
                                        <?php echo e(\Carbon\Carbon::parse($appointment->date)->format('d/m/Y')); ?> - <?php echo e($appointment->time); ?>

                                    </td>
                                    <td class="py-5 px-5 w-full"><?php echo e($appointment->name); ?></td>
                                    <td class="py-5 px-5 w-full"><?php echo e($appointment->sevrices); ?></td>
                                    <td class="py-5 px-5 w-full <?php if($appointment->status == 'Coming Appointment'): ?> text-[#1376F8] <?php endif; ?>">
                                        <?php echo e($appointment->status); ?>

                                    </td>
                                    <td class="py-5 px-5 w-full"><?php echo e($appointment->phone_number); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="mt-12">
                    <h2 class="lg:text-3xl text-2xl font-semibold text-[#011632]">Past Appointment</h2>
                    <div class="lg:overflow-x-visible overflow-x-auto border lg:border-transparent border-[#DDDDDD] lg:mt-7 mt-5">
                        <table class="w-full">
                            <thead>
                                <tr class="bg-[#FFFFFF] text-left text-xs font-semibold text-[#011632] text-nowrap">
                                    <th class="py-5 px-5">DATE AND TIME</th>
                                    <th class="py-5 px-5">NAME</th>
                                    <th class="py-5 px-5">SERVICES</th>
                                    <th class="py-5 px-5">STATUS</th>
                                    <th class="py-5 px-5">PHONE NO.</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $Apointmentments_COMPLETE; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($appointment->status == 'Completed'): ?>
                                <tr class="border border-[#DDDDDD] text-[#011632] text-sm lg:text-nowrap">
                                    <td class="py-5 px-5 w-full">
                                        <?php echo e(\Carbon\Carbon::parse($appointment->date)->format('d/m/Y')); ?> - <?php echo e($appointment->time); ?>

                                    </td>
                                    <td class="py-5 px-5 w-full"><?php echo e($appointment->name); ?></td>
                                    <td class="py-5 px-5 w-full"><?php echo e($appointment->sevrices); ?></td>
                                    <td class="py-5 px-5 w-full">Completed</td>
                                    <td class="py-5 px-5 w-full"><?php echo e($appointment->phone_number); ?></td>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script src="<?php echo e(asset('front_assets/public/js/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/public/js/swiper.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/public/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('front_assets/public/js/index.js')); ?>"></script>
</body><?php /**PATH /home/dmprojects/public_html/ankitsaini/laravel-uifry/resources/views/frontend/apointment_show.blade.php ENDPATH**/ ?>