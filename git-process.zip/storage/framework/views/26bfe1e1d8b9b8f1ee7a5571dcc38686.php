<?php echo e($slot); ?>

<?php /**PATH /home/dmprojects/public_html/ankitsaini/laravel-uifry/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>