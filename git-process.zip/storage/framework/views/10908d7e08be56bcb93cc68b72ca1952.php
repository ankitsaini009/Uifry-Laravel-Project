<?php $__env->startSection('manage_content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h2>Create FAQ</h2><br>
                <form action="<?php echo e(route('faq.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Faq_id" value="<?php echo e((isset($Faq)?$Faq->id:'')); ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="question" class="form-label">Question</label>
                            <input type="text" class="form-control" name="question" placeholder="Enter Question" value="<?php echo e((isset($Faq)?$Faq->question:old('question'))); ?>" autocomplete="off">
                            <?php if($errors->has('question')): ?>
                            <div class="text-danger"><?php echo e($errors->first('question')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="active" <?php echo e((isset($Faq) && $Faq->status == 'active') ? 'selected' : (old('status') == 'active' ? 'selected' : '')); ?>>Active</option>
                                <option value="inactive" <?php echo e((isset($Faq) && $Faq->status == 'inactive') ? 'selected' : (old('status') == 'inactive' ? 'selected' : '')); ?>>Inactive</option>
                            </select>
                            <?php if($errors->has('status')): ?>
                            <div class="text-danger"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label for="description" class="form-label">Answer</label>
                            <textarea name="answer" placeholder="Enter Answer" id="description" class="form-control"><?php echo e((isset($Faq) ? $Faq->answer : old('answer'))); ?></textarea>
                            <?php if($errors->has('answer')): ?>
                            <div class="text-danger"><?php echo e($errors->first('answer')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br><br>
                    <div class="text-center">
                        <button type="submit" class="btn btn-danger"><?php echo e((isset($Faq)? "Update" : "Create")); ?></button>
                        <a href="<?php echo e(route('faq.index')); ?>" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    // CKEDITOR.replace('description');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dmprojects/public_html/ankitsaini/laravel-uifry/resources/views/admin/faq/add.blade.php ENDPATH**/ ?>