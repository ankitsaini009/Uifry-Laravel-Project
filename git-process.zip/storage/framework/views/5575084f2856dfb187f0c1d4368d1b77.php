<?php $__env->startSection('manage_content'); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<div class="content-body">
    <div class="container-fluid">
        <h3 class="text-center"> Well Come To Your Dashboard </h3>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-mQ93gk4fAa5q2SM9Klyz0QZfZZ8tY8hvHdU7F3y0p8lWQ4G21B0z1yboM+77aumB" crossorigin="anonymous"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dmprojects/public_html/ankitsaini/laravel-uifry/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>