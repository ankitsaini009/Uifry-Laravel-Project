<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/dmprojects/public_html/ankitsaini/laravel-uifry/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>