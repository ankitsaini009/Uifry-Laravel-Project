<?php $__env->startSection('manage_content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h2>Edit Appointment</h2><br>
                <form action="<?php echo e(route('appointments.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Appointment_id" value="<?php echo e((isset($Appointment)?$Appointment->id:'')); ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" placeholder="Enter First Name" value="<?php echo e((isset($Appointment)?$Appointment->name:old('name'))); ?>" autocomplete="off">
                            <?php if($errors->has('name')): ?>
                            <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="text" class="form-control" name="email" placeholder="Enter Email" value="<?php echo e((isset($Appointment)?$Appointment->email:old('lname'))); ?>" autocomplete="off">
                            <?php if($errors->has('email')): ?>
                            <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" name="phone" placeholder="Enter Phone Number" value="<?php echo e((isset($Appointment)?$Appointment->phone_number:old('lname'))); ?>" autocomplete="off">
                            <?php if($errors->has('phone')): ?>
                            <div class="text-danger"><?php echo e($errors->first('phone')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br><br>
                    <div class="text-center">
                        <button type="submit" class="btn btn-danger"><?php echo e((isset($Appointment)? "Update" : "Create")); ?></button>
                        <a href="<?php echo e(route('appointments.index')); ?>" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    // CKEDITOR.replace('description');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel-uifry\resources\views\admin\appointments\add.blade.php ENDPATH**/ ?>