<?php $__env->startSection('manage_content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Please fix the following errors:</strong>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php endif; ?>
            <div class="col-12">
                <h2>Services Banner Edit</h2><br>
                <form action="<?php echo e(route('bannerEdit.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Service_banner_id" value="<?php echo e((isset($jsonData2)?$jsonData2->id:'')); ?>">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label for="banner_title" class="form-label">Services Banner Title</label>
                            <input type="text" class="form-control" name="banner_title" placeholder="Services Banner Title" value="<?php echo e(old('banner_title', isset($PagesContantManage) ? $PagesContantManage['banner_title'] : '')); ?>">
                        </div>
                        <div class="col-md-12 mb-3">
                            <label for="banner_description" class="form-label">Services Banner Description</label>
                            <textarea class="form-control" name="banner_description" placeholder="Services Banner Description"><?php echo e(old('banner_description', isset($PagesContantManage) ? $PagesContantManage['banner_description'] : '')); ?></textarea>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="bannerImage" class="form-label">Services Banner Image</label>
                            <?php if(isset($PagesContantManage) && isset($PagesContantManage['bannerImage'])): ?>

                            <div class="mb-2">
                                <img src="<?php echo e(asset('uploads/' . $PagesContantManage['bannerImage'])); ?>" alt="User Image" class="img-thumbnail" width="100">
                            </div>

                            <input type="hidden" value="<?php echo e(old('bannerImage', isset($PagesContantManage) ? $PagesContantManage['bannerImage'] : '')); ?>" class="form-control" name="bannerImage" autocomplete="off">

                            <?php endif; ?>
                            <input type="file" class="form-control" name="bannerImage">
                        </div>
                    </div>
                    <br><br>
                    <div class="text-center">
                        <button type="submit" class="btn btn-danger">Update</button>
                        <a href="<?php echo e(route('services.index')); ?>" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dmprojects/public_html/ankitsaini/laravel-uifry/resources/views/admin/services/editbanner.blade.php ENDPATH**/ ?>