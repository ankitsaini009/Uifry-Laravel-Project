<?php $__env->startSection('manage_content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h2>Blog Categories</h2><br>

                <!-- Blog Form -->
                <form action="<?php echo e(route('blog_cat.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="row">
                        <!-- Blog Category -->
                        <div class="col-md-6 mb-3">
                            <label for="blog_cat" class="form-label">Blog Category</label>
                            <input type="text" class="form-control" name="blog_cat" placeholder="Enter Blog Category"
                                value="<?php echo e(isset($Blog) ? $Blog->blog_cat : old('blog_cat')); ?>" autocomplete="off">
                            <?php if($errors->has('blog_cat')): ?>
                            <div class="text-danger"><?php echo e($errors->first('blog_cat')); ?></div>
                            <?php endif; ?>
                        </div>

                        <!-- Status -->
                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="active" <?php echo e((isset($Blog) && $Blog->status == 'active') ? 'selected' : (old('status') == 'active' ? 'selected' : '')); ?>>Active</option>
                                <option value="inactive" <?php echo e((isset($Blog) && $Blog->status == 'inactive') ? 'selected' : (old('status') == 'inactive' ? 'selected' : '')); ?>>Inactive</option>
                            </select>
                            <?php if($errors->has('status')): ?>
                            <div class="text-danger"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-danger"><?php echo e(isset($Blog) ? "Update" : "Create"); ?></button>
                    </div>
                </form>

                <hr>

                <!-- Blog Category List -->
                <h3 class="mt-5">Blog Categories List</h3>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Blog Category</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blogCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($category->cat_name); ?></td>
                            <td>
                                <span class="badge <?php echo e($category->status == 'active' ? 'bg-success' : 'bg-danger'); ?>">
                                    <?php echo e(ucfirst($category->status)); ?>

                                </span>
                            </td>
                            <td>
                                <form action="<?php echo e(route('blogs.destroy.cat', $category->id)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>

<!-- Quill & CKEditor -->
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dmprojects/public_html/ankitsaini/laravel-uifry/resources/views/admin/blogs/creat_cat.blade.php ENDPATH**/ ?>