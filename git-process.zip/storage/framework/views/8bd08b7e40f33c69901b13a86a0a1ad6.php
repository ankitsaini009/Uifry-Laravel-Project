<?php $__env->startSection('manage_content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h2>Create Blog Comment</h2><br>
                <form action="<?php echo e(route('coment.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Blogcoment_id" value="<?php echo e((isset($Blogcoment)?$Blogcoment->id:'')); ?>">
                    <div class="row">

                        <div class="col-md-6 mb-3">
                            <label for="title" class="form-label">Users</label>
                            <select name="user_id" id="user_id" class="form-control">
                                <option value="">Select User</option>
                                <?php $__currentLoopData = $Users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->name); ?>" <?php echo e((isset($Blogcoment) && $Blogcoment->user_id == $user->name) ? 'selected' : (old('user_id'))); ?>><?php echo e($user->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('user_id')): ?>
                            <div class="text-danger"><?php echo e($errors->first('user_id')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="title" class="form-label">Blogs</label>
                            <select name="blog_id" id="blog_id" class="form-control">
                                <option value="">Select Blogs</option>
                                <?php $__currentLoopData = $Blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($Blogs->title); ?>" <?php echo e((isset($Blogcoment) && $Blogcoment->blog_id == $Blogs->title) ? 'selected' : (old('blog_id'))); ?>><?php echo e($Blogs->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                            <?php if($errors->has('blog_id')): ?>
                            <div class="text-danger"><?php echo e($errors->first('blog_id')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label for="description" class="form-label">Comment</label>
                            <textarea name="description" placeholder="Enter Comment" id="description" class="form-control"><?php echo e((isset($Blogcoment) ? $Blogcoment->description : old('description'))); ?></textarea>
                            <?php if($errors->has('description')): ?>
                            <div class="text-danger"><?php echo e($errors->first('description')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" placeholder="Enter Name" value="<?php echo e((isset($Blogcoment)?$Blogcoment->name:old('name'))); ?>" autocomplete="off">
                            <?php if($errors->has('name')): ?>
                            <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" placeholder="Enter Email" value="<?php echo e((isset($Blogcoment)?$Blogcoment->email:old('email'))); ?>" autocomplete="off">
                            <?php if($errors->has('email')): ?>
                            <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="website" class="form-label">Website</label>
                            <input type="text" class="form-control" name="website" value="<?php echo e((isset($Blogcoment)?$Blogcoment->email:old('website'))); ?>" autocomplete="off">
                            <?php if($errors->has('website')): ?>
                            <div class="text-danger"><?php echo e($errors->first('website')); ?></div>
                            <?php endif; ?>
                        </div>


                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="active" <?php echo e((isset($Blogcoment) && $Blogcoment->status == 'active') ? 'selected' : (old('status') == 'active' ? 'selected' : '')); ?>>Active</option>
                                <option value="inactive" <?php echo e((isset($Blogcoment) && $Blogcoment->status == 'inactive') ? 'selected' : (old('status') == 'inactive' ? 'selected' : '')); ?>>Inactive</option>
                            </select>
                            <?php if($errors->has('status')): ?>
                            <div class="text-danger"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>

                    </div>
                    <br><br>
                    <div class="text-center">
                        <button type="submit" class="btn btn-danger"><?php echo e((isset($Blog)? "Update" : "Create")); ?></button>
                        <a href="<?php echo e(route('blogs.index')); ?>" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel-uifry\resources\views\admin\coments\add.blade.php ENDPATH**/ ?>