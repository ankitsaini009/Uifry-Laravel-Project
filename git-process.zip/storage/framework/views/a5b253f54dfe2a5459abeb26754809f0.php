<?php $__env->startSection('manage_content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h2>Create User</h2><br>
                <form action="<?php echo e(route('user.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="<?php echo e((isset($userdata)?$userdata->id:'')); ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">User Name</label>
                            <input type="text" class="form-control" name="name" placeholder="Enter User Name" value="<?php echo e((isset($userdata)?$userdata->name:old('name'))); ?>" autocomplete="off">
                            <?php if($errors->has('name')): ?>
                            <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" placeholder="Enter Email" value="<?php echo e((isset($userdata)?$userdata->email:old('email'))); ?>" autocomplete="off">
                            <?php if($errors->has('email')): ?>
                            <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                            <?php endif; ?>
                        </div>

                        <?php if(!isset($userdata)): ?>
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" name="password" placeholder="Enter Password" autocomplete="new-password">
                            <?php if($errors->has('password')): ?>
                            <div class="text-danger"><?php echo e($errors->first('password')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="password_confirmation" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" autocomplete="new-password">
                            <?php if($errors->has('password_confirmation')): ?>
                            <div class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></div>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label">Update Password</label>
                            <input type="password" class="form-control" name="password" placeholder="Enter Password" autocomplete="new-password">
                            <?php if($errors->has('password')): ?>
                            <div class="text-danger"><?php echo e($errors->first('password')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="password_confirmation" class="form-label">Confirm New Password</label>
                            <input type="password" class="form-control" name="password_confirmation" placeholder="Confirm Password" autocomplete="new-password">
                            <?php if($errors->has('password_confirmation')): ?>
                            <div class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></div>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="number" class="form-control" name="phone" placeholder="Enter Phone Number" value="<?php echo e((isset($userdata)?$userdata->phone:old('phone'))); ?>" autocomplete="off">
                            <?php if($errors->has('phone')): ?>
                            <div class="text-danger"><?php echo e($errors->first('phone')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="active" <?php echo e((isset($userdata) && $userdata->status == 'active') ? 'selected' : (old('status') == 'active' ? 'selected' : '')); ?>>Active</option>
                                <option value="inactive" <?php echo e((isset($userdata) && $userdata->status == 'inactive') ? 'selected' : (old('status') == 'inactive' ? 'selected' : '')); ?>>Inactive</option>
                            </select>
                            <?php if($errors->has('status')): ?>
                            <div class="text-danger"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="image" class="form-label">Image</label>
                            <?php if(isset($userdata) && $userdata->image): ?>
                            <div class="mb-2">
                                <img src="<?php echo e(asset('images/' . $userdata->image)); ?>" alt="User Image" class="img-thumbnail" width="100">
                            </div>
                            <input type="hidden" value="<?php echo e((isset($userdata)?$userdata->image:old('image'))); ?>" class="form-control" name="image" autocomplete="off">
                            <?php endif; ?>
                            <input type="file" class="form-control" name="image" autocomplete="off">
                            <?php if($errors->has('image')): ?>
                            <div class="text-danger"><?php echo e($errors->first('image')); ?></div>
                            <?php endif; ?>
                        </div>

                    </div>
                    <div class="text-center">
                        <button type="submit" class="btn btn-danger"><?php echo e((isset($userdata)? "Update User" : "Create User")); ?></button>
                        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">Back to Users</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel-uifry\resources\views\admin\users\add.blade.php ENDPATH**/ ?>