<?php $__env->startSection('manage_content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h2>Create Blog</h2><br>
                <form action="<?php echo e(route('blogs.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="blog_id" value="<?php echo e((isset($Blog)?$Blog->id:'')); ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" name="title" placeholder="Enter Title" value="<?php echo e((isset($Blog)?$Blog->title:old('title'))); ?>" autocomplete="off">
                            <?php if($errors->has('title')): ?>
                            <div class="text-danger"><?php echo e($errors->first('title')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="auther" class="form-label">Author Name</label>
                            <input type="text" class="form-control" name="auther" placeholder="Enter Author" value="<?php echo e((isset($Blog)?$Blog->auther:old('auther'))); ?>" autocomplete="off">
                            <?php if($errors->has('auther')): ?>
                            <div class="text-danger"><?php echo e($errors->first('auther')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="image" class="form-label">Blog Image</label>
                            <?php if(isset($Blog) && $Blog->image): ?>
                            <div class="mb-2">
                                <img src="<?php echo e(asset('images/' . $Blog->image)); ?>" alt="User Image" class="img-thumbnail" width="100">
                            </div>
                            <input type="hidden" value="<?php echo e((isset($Blog)?$Blog->image:old('image'))); ?>" class="form-control" name="image" autocomplete="off">
                            <?php endif; ?>
                            <input type="file" class="form-control" name="image" autocomplete="off">
                            <?php if($errors->has('image')): ?>
                            <div class="text-danger"><?php echo e($errors->first('image')); ?></div>
                            <?php endif; ?>
                        </div>


                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="active" <?php echo e((isset($Blog) && $Blog->status == 'active') ? 'selected' : (old('status') == 'active' ? 'selected' : '')); ?>>Active</option>
                                <option value="inactive" <?php echo e((isset($Blog) && $Blog->status == 'inactive') ? 'selected' : (old('status') == 'inactive' ? 'selected' : '')); ?>>Inactive</option>
                            </select>
                            <?php if($errors->has('status')): ?>
                            <div class="text-danger"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea name="description" placeholder="Enter Description" id="description" class="form-control"><?php echo e((isset($Blog) ? $Blog->description : old('description'))); ?></textarea>
                            <?php if($errors->has('description')): ?>
                            <div class="text-danger"><?php echo e($errors->first('description')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br><br>
                    <div class="text-center">
                        <button type="submit" class="btn btn-danger"><?php echo e((isset($Blog)? "Update" : "Create")); ?></button>
                        <a href="<?php echo e(route('blogs.index')); ?>" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\laravel-uifry\resources\views\admin\blogs\add.blade.php ENDPATH**/ ?>