<?php $__env->startSection('manage_content'); ?>
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h2>Create Specialist</h2><br>
                <form action="<?php echo e(route('specialists.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="Specialist_id" value="<?php echo e((isset($Specialist)?$Specialist->id:'')); ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" placeholder="Enter Name" value="<?php echo e((isset($Specialist)?$Specialist->name:old('name'))); ?>" autocomplete="off">
                            <?php if($errors->has('name')): ?>
                            <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="specialization" class="form-label">Specialization</label>
                            <input type="text" class="form-control" name="specialization" placeholder="Enter Specialization" value="<?php echo e((isset($Specialist)?$Specialist->specialization:old('specialization'))); ?>" autocomplete="off">
                            <?php if($errors->has('specialization')): ?>
                            <div class="text-danger"><?php echo e($errors->first('specialization')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="experience" class="form-label">Experience</label>
                            <input type="text" class="form-control" name="experience" placeholder="Enter Experience" value="<?php echo e((isset($Specialist)?$Specialist->experience:old('experience'))); ?>" autocomplete="off">
                            <?php if($errors->has('experience')): ?>
                            <div class="text-danger"><?php echo e($errors->first('experience')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="linkdin_profile_link" class="form-label">Linkdin Profile Link</label>
                            <input type="text" class="form-control" name="linkdin_profile_link" placeholder="Enter Linkdin Profile Link" value="<?php echo e((isset($Specialist)?$Specialist->linkdin_profile_link:old('linkdin_profile_link'))); ?>" autocomplete="off">
                            <?php if($errors->has('linkdin_profile_link')): ?>
                            <div class="text-danger"><?php echo e($errors->first('linkdin_profile_link')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" placeholder="Enter email" value="<?php echo e((isset($Specialist)?$Specialist->email:old('email'))); ?>" autocomplete="off">
                            <?php if($errors->has('email')): ?>
                            <div class="text-danger"><?php echo e($errors->first('email')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="contact_number" class="form-label">Contact Number</label>
                            <input type="text" class="form-control" name="contact_number" placeholder="Enter Contact Number" value="<?php echo e((isset($Specialist)?$Specialist->contact_number:old('contact_number'))); ?>" autocomplete="off">
                            <?php if($errors->has('contact_number')): ?>
                            <div class="text-danger"><?php echo e($errors->first('contact_number')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="image" class="form-label">Profile Image</label>
                            <?php if(isset($Specialist) && $Specialist->profile_photo): ?>
                            <div class="mb-2">
                                <img src="<?php echo e(asset('images/' . $Specialist->profile_photo)); ?>" alt="User Image" class="img-thumbnail" width="100">
                            </div>
                            <input type="hidden" value="<?php echo e((isset($Specialist)?$Specialist->profile_photo:old('image'))); ?>" class="form-control" name="image" autocomplete="off">
                            <?php endif; ?>
                            <input type="file" class="form-control" name="image" autocomplete="off">
                            <?php if($errors->has('image')): ?>
                            <div class="text-danger"><?php echo e($errors->first('image')); ?></div>
                            <?php endif; ?>
                        </div>


                        <div class="col-md-6 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" class="form-control">
                                <option value="active" <?php echo e((isset($Specialist) && $Specialist->status == 'active') ? 'selected' : (old('status') == 'active' ? 'selected' : '')); ?>>Active</option>
                                <option value="inactive" <?php echo e((isset($Specialist) && $Specialist->status == 'inactive') ? 'selected' : (old('status') == 'inactive' ? 'selected' : '')); ?>>Inactive</option>
                            </select>
                            <?php if($errors->has('status')): ?>
                            <div class="text-danger"><?php echo e($errors->first('status')); ?></div>
                            <?php endif; ?>
                        </div>

                        <div class="col-md-12 mb-3">
                            <label for="description" class="form-label">About Specialist</label>
                            <textarea name="description" placeholder="Enter Description" id="description" class="form-control"><?php echo e((isset($Specialist) ? $Specialist->description : old('description'))); ?></textarea>
                            <?php if($errors->has('description')): ?>
                            <div class="text-danger"><?php echo e($errors->first('description')); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <br><br>
                    <div class="text-center">
                        <button type="submit" class="btn btn-danger"><?php echo e((isset($Specialist)? "Update" : "Create")); ?></button>
                        <a href="<?php echo e(route('specialists.index')); ?>" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('description');
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dmprojects/public_html/ankitsaini/laravel-uifry/resources/views/admin/specialists/add.blade.php ENDPATH**/ ?>